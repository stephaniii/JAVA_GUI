import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class submitty
    extends JFrame
    implements ActionListener {
        public static void main(String[] args) {
            EventQueue.invokeLater(new Runnable() {
                public void run() {
                    submitty frame2 = new submitty();
                    frame2.setVisible(true);
                    }
                    });
        }

    private Container c;
    private JLabel title;
    private JButton button;
    public JTextArea tout;
    public JTextArea nextpage;
    
    
    public submitty()
    {
        setTitle("STOU_APP");
        setBounds(240,0, 1000, 820);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        setResizable(true);
        
        Font font1 = new Font("Angsana New" , Font.BOLD , 20);
        c = getContentPane();
        c.setLayout(null);
        c.setBackground(Color.LIGHT_GRAY);

        JPanel panel = new JPanel();
		panel.setBounds(288, 10, 410, 115);
		c.add(panel);
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setLayout(new GridLayout(0, 1, 0, 0));

        title = new JLabel("รายละเอียดของผู้สมัคร");
        title.setBackground(Color.LIGHT_GRAY);
        title.setFont(font1);
        title.setSize(300, 30);
        title.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(title);
        


        button = new JButton("แก้ไข");
        button.setFont(font1);
        button.setSize(100, 20);
        button.setLocation(150, 750);
        button.setBounds(472, 746, 66, 21);
        button.addActionListener(this);
        c.add(button);

        nextpage = new JTextArea();
        nextpage.setFont(font1);
        nextpage.setSize(1000, 800);
        nextpage.setLocation(240,100);
        nextpage.setLineWrap(true);
        nextpage.setBackground(Color.LIGHT_GRAY);
        nextpage.setEditable(false);
        c.add(nextpage);

        setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e)
    {
        if (e.getSource() == button) {
            submitty frame = new submitty();
            frame.setVisible(true);
            setVisible(false);
        }
        else {
            String def = "1";
        }
    }
}