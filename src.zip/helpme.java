import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class helpme implements ActionListener{
	private static JFrame stouapp;
	private JTextField dat,dat_1,dat_2,dat_3,dat_4,dat_6;
	private JComboBox att1,att2,att3,att4,att5,needpos1,needpos2,needpos3;
	private JRadioButton btt,btt1;
	private Button button ;
	public JTextArea nextpage;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				helpme f1 = new helpme();
				stouapp	.setVisible(true);
			}
		});
	}
	public helpme() {
		initialize();
	}
	private void initialize() {
		stouapp = new JFrame();
		stouapp.setBounds(240,0, 1000, 805);
		stouapp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		stouapp.setVisible(true);
		stouapp.getContentPane().setLayout(null);

		Font font1 = new Font("Angsana New" , Font.BOLD , 16);
		JLabel appid = new JLabel("เลขประจำตัวของผู้สมัคร (AP_ID) : ");
		appid.setBounds(10, 130, 250, 13);
		appid.setFont(font1);
		stouapp.getContentPane().add(appid);
		
		JLabel name_sure = new JLabel("ชื่อ-นามสกุล (AP_NAME)");
		name_sure.setBounds(10, 160, 167, 13);
		name_sure.setFont(font1);
		stouapp.getContentPane().add(name_sure);
		
		JLabel addr = new JLabel("ที่อยู่ (AP_ADDRESS) :");
		addr.setBounds(10, 190, 250, 13);
		addr.setFont(font1);
		stouapp.getContentPane().add(addr);
		
		JLabel province = new JLabel("จังหวัด (AP_CHW)");
		province.setBounds(10, 220, 132, 13);
		province.setFont(font1);
		stouapp.getContentPane().add(province);
		
		JLabel sexd = new JLabel("เพศ (AP_SEX): ");
		sexd.setBounds(10, 250, 160, 13);
		sexd.setFont(font1);
		stouapp.getContentPane().add(sexd);
		
		JLabel educate = new JLabel("วุฒิการศึกษาชั้นสูงสุด (AP_ED) : ");
		educate.setBounds(10, 280, 160, 21);
		educate.setFont(font1);
		stouapp.getContentPane().add(educate);
		
		JLabel newtil = new JLabel("เช่น (B.S,B.A,M.S.,M.BA.,M.A) : ");
		newtil.setBounds(20, 300, 160, 13);
		newtil.setFont(font1);
		stouapp.getContentPane().add(newtil);
		
		JLabel maj = new JLabel("วิชาเอก (AP_MAJ) :");
		maj.setBounds(10, 330, 132, 13);
		maj.setFont(font1);
		stouapp.getContentPane().add(maj);
		
		dat = new JTextField();
		dat.setBounds(182, 129, 300, 22);
		stouapp.getContentPane().add(dat);
		dat.setFont(font1);
		dat.setColumns(10);
		
		dat_1 = new JTextField();
		dat_1.setBounds(182, 159, 300, 22);
		dat_1.setFont(font1);
		stouapp.getContentPane().add(dat_1);
		dat_1.setColumns(10);
		
		dat_2 = new JTextField();
		dat_2.setBounds(182, 189, 300, 22);
		dat_2.setFont(font1);
		stouapp.getContentPane().add(dat_2);
		dat_2.setColumns(10);
		
		dat_3 = new JTextField();
		dat_3.setBounds(182, 219, 300, 22);
		dat_3.setFont(font1);
		stouapp.getContentPane().add(dat_3);
		dat_3.setColumns(10);
		
		dat_4 = new JTextField();
		dat_4.setBounds(182, 279, 300, 22);
		dat_4.setFont(font1);
		stouapp.getContentPane().add(dat_4);
		dat_4.setColumns(10);
		
		dat_6 = new JTextField();
		dat_6.setBounds(182, 329, 300, 22);
		dat_6.setFont(font1);
		stouapp.getContentPane().add(dat_6);
		dat_6.setColumns(10);
		
		JPanel gender = new JPanel();
		gender.setBounds(180, 242, 182, 27);
		stouapp.getContentPane().add(gender);
		
		btt = new JRadioButton("ชาย");
		btt.setFont(font1);
		gender.add(btt);
		
		btt1 = new JRadioButton("หญิง");
		btt1.setFont(font1);
		gender.add(btt1);
		
		JPanel Attrib = new JPanel();
		Attrib.setBounds(10, 385, 463, 159);
		stouapp.getContentPane().add(Attrib);
		
		Font font2 = new Font("Angsana New" , Font.BOLD , 16);
		Attrib.setLayout(null);
		
		JLabel speci = new JLabel("ความรู้ความสามารถหรือคุณสมบัติเฉพาะตำแหน่ง (QUAL_DESC)(ตอบได้ไม่เกิน 5 รายการ)");
		speci.setBounds(22, 5, 441, 17);
		Attrib.add(speci);
		speci.setFont(font2);
		
		JLabel atb1 = new JLabel("ความรู้ความสามารถ 1");
		atb1.setBounds(12, 32, 100, 20);
		atb1.setFont(font2);
		Attrib.add(atb1);
		
		JLabel atb2 = new JLabel("ความรู้ความสามารถ 2");
		atb2.setBounds(12, 55, 100, 20);
		atb2.setFont(font2);
		Attrib.add(atb2);
		
		JLabel atb3 = new JLabel("ความรู้ความสามารถ 3");
		atb3.setBounds(12, 78, 100, 20);
		atb3.setFont(font2);
		Attrib.add(atb3);
		
		JLabel atb4 = new JLabel("ความรู้ความสามารถ 4");
		atb4.setBounds(12, 101, 100, 20);
		atb4.setFont(font2);
		Attrib.add(atb4);
		
		JLabel atb5 = new JLabel("ความรู้ความสามารถ 5");
		atb5.setBounds(12, 124, 100, 20);
		atb5.setFont(font2);
		Attrib.add(atb5);
		
		String attrib[] = {"เลือกความรู้ความสามารถ  ", "ASP", "C++", "DB2", "DBA_OR", "GRP_DS", "JAVA", "MGT", "NW", "SE_45", "SE_60", "SYS_1", "SYS_2", "VB"};
		String job[]= { "เลือกตำแหน่งที่ต้องการสมัคร", "PS001 : Technical Programmer", "PS002 : Web Developer", "PS003 : General Manager", "PS004 : ICT Specialist", "PS005 : E-Business Analyst", "PS006 : ICT Document", "PS007 : Database Administrator", "PS008 : PC Administrator", "PS009 : Network Specialist", "PS010 : ICT Manager"};
		
		
		att1 = new JComboBox();
		att1.setBounds(158, 35, 166, 18);
		att1.setModel(new DefaultComboBoxModel(attrib));
		att1.setFont(font2);
		Attrib.add(att1);
		
		att2 = new JComboBox();
		att2.setBounds(158, 58, 166, 18);
		att2.setModel(new DefaultComboBoxModel(attrib));
		att2.setFont(font2);
		Attrib.add(att2);
		
		att3 = new JComboBox();
		att3.setBounds(158, 81, 166, 18);
		att3.setModel(new DefaultComboBoxModel(attrib));
		att3.setFont(font2);
		Attrib.add(att3);
		
		att4 = new JComboBox();
		att4.setBounds(158, 104, 166, 18);
		att4.setModel(new DefaultComboBoxModel(attrib));
		att4.setFont(font2);
		Attrib.add(att4);
		
		att5 = new JComboBox();
		att5.setBounds(158, 127, 166, 18);
		att5.setModel(new DefaultComboBoxModel(attrib));
		att5.setFont(font2);
		Attrib.add(att5);
		
		JTextArea head = new JTextArea();
		head.setBackground(SystemColor.control);
		head.setEditable(false);
		head.setRows(4);
		head.setFont(new Font("Angsana New", Font.BOLD, 15));
		head.setText("\t\tบริษัท STOU-TEC\r\n\t                            แบบฟอร์มใบสมัครพนักงาน\r\n                   ใบสมัครลำหรับงานด้าน ICT นี้ ให้ผู้สมัครกรอกรายละเอียดต่อไปนี้เพื่อที่\r\n\tบริษัท STOU-TEC จำกัด ทำการคัดเลือกตามความเหมาะสม");
		head.setLineWrap(true);
		head.setWrapStyleWord(true);
		head.setBounds(325, 0, 366, 72);
		stouapp.getContentPane().add(head);
		
		JLabel speci_1 = new JLabel("ตำแหน่งที่ต้องการสมัคร (POS_NAME)(ตอบได้ไม่เกิน 3 รายการ)");
		speci_1.setFont(new Font("Angsana New", Font.BOLD, 16));
		speci_1.setBounds(32, 565, 441, 17);
		stouapp.getContentPane().add(speci_1);
		
		JPanel neebjob = new JPanel();
		neebjob.setBounds(10, 592, 463, 117);
		stouapp.getContentPane().add(neebjob);
		neebjob.setLayout(null);
		
		JLabel pos1 = new JLabel("ตำแหน่งที่ต้องการสมัคร 1");
		pos1.setBounds(0, 0, 139, 35);
		pos1.setFont(font2);
		neebjob.add(pos1);
		
		JLabel pos2 = new JLabel("ตำแหน่งที่ต้องการสมัคร 2");
		pos2.setBounds(0, 35, 139, 35);
		pos2.setFont(font2);
		neebjob.add(pos2);
		
		JLabel pos3 = new JLabel("ตำแหน่งที่ต้องการสมัคร 3 ");
		pos3.setBounds(0, 70, 139, 35);
		pos3.setFont(font2);
		neebjob.add(pos3);
		
		needpos1 = new JComboBox();
		needpos1.setBounds(149, 7, 192, 28);
		needpos1.setFont(font2);
		needpos1.setModel(new DefaultComboBoxModel(job));
		neebjob.add(needpos1);
		
		needpos2 = new JComboBox();
		needpos2.setBounds(149, 42, 192, 28);
		needpos2.setFont(font2);
		needpos2.setModel(new DefaultComboBoxModel(job));
		neebjob.add(needpos2);
		
		needpos3 = new JComboBox();
		needpos3.setBounds(149, 80, 192, 28);
		needpos3.setFont(font2);
		needpos3.setModel(new DefaultComboBoxModel(job));
		neebjob.add(needpos3);
		
		button = new Button("ตกลง");
		button.setBackground(Color.LIGHT_GRAY);
		button.setBounds(473, 730, 80, 21);
		button.setFont(font2);
		button.addActionListener((ActionListener) this);
		stouapp.getContentPane().add(button);
		
		nextpage = new JTextArea();
        nextpage.setFont(new Font("Arial", Font.PLAIN, 15));
        //nextpage.setSize(1000,800);
        nextpage.setLocation(240, 0);
        nextpage.setLineWrap(true);
        nextpage.setEditable(false);
        stouapp.add(nextpage);
       
	}

	public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            // Textfield
            String sx;
            String inform1 = "เลขประจำตัวของผุ้สมัคร :" + dat.getText() + "\n\n"
                    +"ชื่อ-นามสกุล : " + dat_1.getText() +"\n\n"
                    +"ที่อยู่ : " + dat_2.getText() +"\n\n"
                    +"จังหวัด : "+ dat_3.getText() +"\n\n"
                    +"วุฒิการศึกษาชั้นสูงสุด : " + dat_4.getText() +"\n\n"
                    +"วิชาเอก : " + dat_6.getText() +"\n\n";
                if (btt.isSelected())
                    sx = "เพศ : ชาย" + "\n";
                else
                    sx = "เพศ : หญิง" + "\n"; 
            
            //cbbox
            String inform2 = "ความรู้ความสามารถ 1 : "+att1.getSelectedItem().toString()+"\n\n"+
            "ความรู้ความสามารถ 2 : "+att2.getSelectedItem().toString()+"\n\n"+
            "ความรู้ความสามารถ 3 : "+att3.getSelectedItem().toString()+"\n\n"+
            "ความรู้ความสามารถ 4 : "+att4.getSelectedItem().toString()+"\n\n"+
            "ความรู้ความสามารถ 5 : "+att5.getSelectedItem().toString()+"\n\n"+
            "ตำแหน่งที่ต้องการสมัคร 1 : " + needpos1.getSelectedItem().toString() + "\n\n"+
            "ตำแหน่งที่ต้องการสมัคร 2 : " + needpos1.getSelectedItem().toString() + "\n\n"+
            "ตำแหน่งที่ต้องการสมัคร 3 : " + needpos1.getSelectedItem().toString() + "\n\n";
            nextpage.setEditable(true);
            submitty f = new submitty();
            f.nextpage.setText(inform1 + sx + inform2);
            f.setVisible(true);
            stouapp.setVisible(false);
        }
	}

	public helpme(JFrame stouapp) {
		super();
		this.stouapp = stouapp;
		
	}
}
